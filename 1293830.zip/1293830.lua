addappid(1293830)
addappid(1293831, 1, "c6be4a0719d73ba5201e778b7e44d6c9c0e1b4baf33104df4d0da1729751cf7f")
setManifestid(1293831, "7960876371477493357", 0)
addappid(1443091, 1, "cacce7495ef657d5a7e8ae0f89e83fcdbb3f7146e25f8dcf9a4843a74e711aba")
setManifestid(1443091, "1638530373648163875", 0)
addappid(1443092, 1, "bff2e67bf6bdf9001760367fcb99b7d1fba41f17441c648568895843464e2dd3")
setManifestid(1443092, "2636644777724144367", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]